//
//  ColorElement.swift
//  shoppingApp
//
//  Created by 杜襄 on 2021/10/27.
//

import UIKit

struct ColorElement {
    var color: UIColor{
        return UIColor(named: String(indexOfAllColor))!
    }
    var indexOfAllColor: Int
}
