//
//  Category.swift
//  shoppingApp
//
//  Created by 杜襄 on 2021/10/27.
//

import UIKit

struct CategorySiang {
    var title: String
    var image: UIImage
}
